player_manager.AddValidModel( "Deltarune Ralsei", "models/deltarune/ralsei/ralsei.mdl" );
list.Set( "PlayerOptionsModel", "Deltarune Ralsei", "models/deltarune/ralsei/ralsei.mdl" );
player_manager.AddValidHands( "Deltarune Ralsei", "models/deltarune/ralsei/arm.mdl", 0, "main" );

local NPC = {	Name = "Ralsei - Friendly",
				Class = "npc_citizen",
				Model = "models/deltarune/ralsei/ralsei.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
				Category = "Deltarune" }
list.Set( "NPC", "ralsei_f", NPC )


local NPC = {	Name = "Ralsei - Hostile",
				Class = "npc_combine",
				Model = "models/deltarune/ralsei/ralsei.mdl",
				Health = "100",
				Category = "Deltarune" }
list.Set( "NPC", "ralsei_h", NPC )

player_manager.AddValidModel( "Deltarune Alt Ralsei", "models/deltarune/aralsei/aralsei.mdl" );
list.Set( "PlayerOptionsModel", "Deltarune Alt Ralsei", "models/deltarune/aralsei/aralsei.mdl" );
player_manager.AddValidHands( "Deltarune Alt Ralsei", "models/deltarune/aralsei/aarm.mdl", 0, "main" );

local NPC = {	Name = "Alt Ralsei - Friendly",
				Class = "npc_citizen",
				Model = "models/deltarune/aralsei/aralsei.mdl",
				Health = "100",
				KeyValues = { citizentype = 4 },
				Category = "Deltarune" }
list.Set( "NPC", "aralsei_f", NPC )


local NPC = {	Name = "Alt Ralsei - Hostile",
				Class = "npc_combine",
				Model = "models/deltarune/aralsei/aralsei.mdl",
				Health = "100",
				Category = "Deltarune" }
list.Set( "NPC", "aralsei_h", NPC )

--Add Playermodel
player_manager.AddValidModel( "Da'vali", "models/player/da_avali/da_avali_pm.mdl" )
player_manager.AddValidHands( "Da'vali", "models/player/da_avali/da_avali_hands.mdl", 0, "0000000" )


hook.Add("PreDrawPlayerHands", "davali_hands", function(hands, vm, ply, wpn)
    if IsValid(hands) and hands:GetModel() == "models/player/da_avali/da_avali_hands.mdl" then
        hands:SetSkin(ply:GetSkin())
    end
end)

--[[
INFO ABOUT PORT (and porting cosmetics)

- scale is 50x the original FBX (in blender)
- original bones have been included to make porting YOUR OWN cosmetics easier, however you may still have to move cosmetics to playermodel's armature in blender
- due to engine limitations only one (two if draconic base support is added) colour(s) can be changed

--]]